#ifndef BIBLIOTECAS_H_INCLUDED
#define BIBLIOTECAS_H_INCLUDED

#include <iostream>
#include <cstring>
#include <locale.h> // Libreria que contiene la funcion setlocale
#include <stdio.h>
#include <wchar.h>
#include <cstdlib> //Libreria para generar el numero random
#include <ctime>

using namespace std;

#endif // BIBLIOTECAS_H_INCLUDED
